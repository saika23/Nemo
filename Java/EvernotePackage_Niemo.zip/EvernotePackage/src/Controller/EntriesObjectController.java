/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author chris
 */

import java.sql.*;
import Model.Entries;
import java.util.*;

public class EntriesObjectController 
{
    private Connection conn;
    private PreparedStatement pstm;
    
    public void establishConnection()
    {
        try
        {
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost/evernotedb", "root", "");
        }
        catch(Exception ex)
        {
            System.out.println("Can't establish connection. " + ex);
        }
    }
    
    public boolean addEntry(Entries e){
        this.establishConnection();
        boolean success = false;
        String query = "INSERT INTO tbl_entries(title, content) VALUES(?, ?)";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, e.getTitle());
            this.pstm.setString(2, e.getContent());
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't add entry. " + ex);
        }
        
        return success;
    }
    
    public boolean editEntry(Entries e) {
        this.establishConnection();
        boolean success = false;
        String query = "UPDATE tbl_entries SET title = ?, content = ? WHERE id = ?";
        
        try{
                this.pstm = this.conn.prepareStatement(query);
                this.pstm.setString(1, e.getTitle());
                this.pstm.setString(2, e.getContent());

                this.pstm.executeUpdate();
                success = true; 
        }  
        catch(Exception ex){
            System.out.println("Can't edit entry. " + ex);
        }
        
        return success;
    }
    
    public boolean deleteEntry(int id){
        this.establishConnection();
        boolean success = false;
        String query = "DELETE FROM tbl_entries WHERE id = ?";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, id);
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't delete entry. " + ex);
        }
        
        return success;
    }
    
    public ArrayList<Entries> showAllEntries(){
        this.establishConnection();
        String query = "SELECT * FROM tbl_entries";
        Entries e = null;
        ArrayList<Entries> entryList = new ArrayList<>();
        ResultSet rs = null;
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            rs = this.pstm.executeQuery();
            while(rs.next()){
                int id = rs.getInt(1);
                String title = rs.getString(2);
                String content = rs.getString(3);
                String datetime = rs.getString(4);
                
                e = new Entries(id, title, content, datetime);
                entryList.add(e);
            }
        }
        catch(Exception ex){
            System.out.println("Can't view the list of entries. " + ex);
        }
        
        return entryList;
    }
    
      public Entries viewSpecificEntry(int entryId){
        
        this.establishConnection();
        Entries e = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM tbl_entries WHERE id = ?";
        
        try{
        
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, entryId);
            
            rs = this.pstm.executeQuery();
            
            if(rs.next()){
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String content = rs.getString("content");
                String datetime =  rs.getString("datetime");

                e = new Entries(id, title, content, datetime);
            }
            
            else{
                throw new Exception("This entry ID does not exist");
            }
            
        } catch(Exception ex){
            System.out.println("Cannot select entry. " + ex);
        }
        
        return e;
    }
   
}
