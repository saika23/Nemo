/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

/**
 *
 * @author chris
 */

import Controller.EntriesObjectController;
import Model.Entries;
import java.util.*;

public class Main {
     public static void main(String args[]) throws Exception
     {
        Scanner cin = new Scanner(System.in);
         
        int choice = 0, id = 0, entryId = 0;
        String title = "", content = "";
        
        EntriesObjectController eoc = new EntriesObjectController();
        Entries e = null;
        do
        {
            System.out.println("[1] View All Entries");
            System.out.println("[2] View Specific Entry");
            System.out.println("[3] Add Entry");
            System.out.println("[4] Edit Entry");
            System.out.println("[5] Delete Entry");
            System.out.println("[6] Exit");
            System.out.print("Choose an option: ");
            choice = Integer.parseInt(cin.nextLine());
            
            switch(choice)
            {
                case 1: 
                    ArrayList<Entries> entryList = eoc.showAllEntries();
                        if(entryList != null){
                            for(Entries e2 : entryList){
                                System.out.println("ID: " + e2.getId());
                                System.out.println("Title: " + e2.getTitle());
                                System.out.println("Content: " + e2.getContent());
                                System.out.println("Date Time: " + e2.getDatetime());
                            }
                        }
                        else{
                            System.out.println("No entry found.");
                        }
                        break;
                case 2:
                    System.out.print("Enter entry id: ");
                    entryId = Integer.parseInt(cin.nextLine());
                    
                    e = eoc.viewSpecificEntry(entryId);
                    
                    if (e != null) {
                        System.out.println("User ID: " + e.getId());
                        System.out.println("Title: " + e.getTitle());
                        System.out.println("Content: " + e.getContent());
                        System.out.println("Date Time: " + e.getDatetime());
                    }
                    
                    break;
                case 3:
                    System.out.print("Enter title: ");
                    title = cin.nextLine();
                    System.out.print("Enter content: ");
                    content = cin.nextLine();
                    e = new Entries(title, content);
                        
                    if(eoc.addEntry(e)){
                        System.out.println("Entry successfully inserted.");
                    }
                    else{
                        System.out.println("Entry not added.");
                    }
                    break;      
                case 4:
                    System.out.println("Enter id that you want to edit: ");
                            id = Integer.parseInt(cin.nextLine());
                            
                            e = eoc.viewSpecificEntry(entryId);
                            
                            if(e != null){
                            System.out.print("Enter name: ");
                            title = cin.nextLine();
                            System.out.print("Enter age: ");
                            content = cin.nextLine();
                            e = new Entries(title, content);

                                if(eoc.editEntry(e)){
                                    System.out.println("Entry successfully edited.");
                                }
                                else{
                                    System.out.println("Editing failed.");
                                }  
                            }    
                    break;
                case 5:
                    System.out.println("Enter id that you want to delete: ");
                    id = Integer.parseInt(cin.nextLine());;
                        
                    if(eoc.deleteEntry(id)){
                        System.out.println("User successfully deleted.");
                    }
                    else{
                        System.out.println("Deleting failed.");
                    }
                    break;
            }
        }
        while(choice != 6);
    }   
}
