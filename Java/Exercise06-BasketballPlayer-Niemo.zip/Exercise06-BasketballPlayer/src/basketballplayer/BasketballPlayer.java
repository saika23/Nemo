/* Exercise 06

This challenge activitiy should ask for the following inputs:
- a basketball player's name
- average points per game
- height in inches

and then display the player name, average points per game, 
and height in ft and inches

There are 12 inches in 1 ft. so 75 inches is 6ft 3 inches

 */
package basketballplayer;
/**
 *
 * @author onadc
 */
import java.util.*;

public class BasketballPlayer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner (System.in);
        
        System.out.print("Input Player Name: ");
    String name = sc.nextLine();
    System.out.print("Input Average Points per Game: ");
    double avepoints = sc.nextDouble();
    System.out.print("Input Height in Inches: ");
    double height = sc.nextDouble();
    
    double ft = (int)height/12;
    double inch = height%12;
    
    System.out.println("Player Name: " + name);
    System.out.println("Average Points per Game: " + avepoints);
    System.out.println("Height: " + ft + "foot. " + inch + "inches.");
    }
}
    
