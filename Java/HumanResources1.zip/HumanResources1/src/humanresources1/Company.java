/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humanresources1;

/**
 *
 * @author chris
 */
public class Company 
{
    private String companyName;
    private String companyLocation;
    
    public Company(String companyName, String companyLocation){
        this.companyName = companyName;
        this.companyLocation = companyLocation;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setCompanyLocation(String companyLocation) {
        this.companyLocation = companyLocation;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getCompanyLocation() {
        return companyLocation;
    }
    
    public static void main(String args[]){
        Employee emp = new Employee(1690, "Niemo", "nienmo@outlook.com", 100);
        Department dept = new Department(86, "InfoTech", "Nice Aircons");
        Company com = new Company("MFI Polytechnic", "Pasig City");
        
        System.out.print("Company Name: " + com.getCompanyName());
        System.out.print("Location: " + com.getCompanyLocation());
        
        System.out.print("Department ID: " + dept.getDepartmentId());
        System.out.print("Department Name: " + dept.getDepartmentName());
        System.out.print("Department Description: " + dept.getDepartmentDesc());
        
        emp.displayEmployeeInfo();
        
        System.out.println("Gross Salary: " + emp.computeGrossSalary(8));
    }
}
