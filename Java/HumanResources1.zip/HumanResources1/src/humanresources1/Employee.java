/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humanresources1;

/**
 *
 * @author chris
 */
public class Employee {

    /**
     * @param args the command line arguments
     */
    private int employeeId;
    private String employeeName;
    private String employeeEmail;
    private double basicSalary;
    private int hrsWorked;
    private double GrossSalary;
    
    public Employee(int employeeId, String employeeName, String employeeEmail, double basicSalary)
    {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeeEmail = employeeEmail;
        this.basicSalary = basicSalary;
    }
    
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public void setEmployeeEmail(String employeeEmail) {
        this.employeeEmail = employeeEmail;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public void setHrsWorked(int hrsWorked) {
        this.hrsWorked = hrsWorked;
    }
    
    public int getEmployeeId() {
        return employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getEmployeeEmail() {
        return employeeEmail;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public int getHrsWorked() {
        return hrsWorked;
    }
 
    public double computeGrossSalary(int hrsWorked){
        return GrossSalary = this.basicSalary*hrsWorked;
    }
    
     public void displayEmployeeInfo()
    {
        System.out.print("\nEmployee Id: " + this.getEmployeeId());
        System.out.println("\nEmployeeName: " + this.getEmployeeName());
        System.out.println("EmployeeEmail: " + this.getEmployeeEmail());
        System.out.println("Basic Salary: " + this.getBasicSalary());
    }
}
