/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

/**
 *
 * @author chris
 */
import Controller.ItemsObjectController;
import Model.Items;
import java.util.*;

public class Main {
    public static void main(String args[]) throws Exception
     {
        Scanner cin = new Scanner(System.in);
         
        int choice = 0, id = 0, itemId = 0, quantity = 0;
        String name = "", itemName = "";
        double price = 0;
        
        ItemsObjectController eoc = new ItemsObjectController();
        Items i= null;
        do
        {
            System.out.println("[1] View All Item");
            System.out.println("[2] View Specific Item");
            System.out.println("[3] Add Item");
            System.out.println("[4] Edit Item");
            System.out.println("[5] Delete Item");
            System.out.println("[6] Exit");
            System.out.print("Choose an option: ");
            choice = Integer.parseInt(cin.nextLine());
            
            switch(choice)
            {
                case 1: 
                    ArrayList<Items> itemList = eoc.showAllItems();
                        if(itemList != null){
                            for(Items e2 : itemList){
                                System.out.println("ID: " + e2.getId());
                                System.out.println("Name: " + e2.getName());
                                System.out.println("Quantity: " + e2.getQuantity());
                                System.out.println("Price: " + e2.getPrice());
                            }
                        }
                        else{
                            System.out.println("No Item found.");
                        }
                        break;
                case 2:
                    System.out.print("Enter item id: ");
                    itemId = Integer.parseInt(cin.nextLine());
                    
                    i = eoc.viewSpecificItem(itemId);
                    
                    if (i != null) {
                        System.out.println("ID: " + i.getId());
                        System.out.println("Name: " + i.getName());
                        System.out.println("Quantity: " + i.getQuantity());
                        System.out.println("Price: " + i.getPrice());
                    }
                    
                    break;
                case 3:
                    System.out.print("Enter name: ");
                    name = cin.nextLine();
                    
                    int i2 = eoc.viewDuplicate(itemName);
                    
                    if(i2 == 0)
                    {
                        System.out.print("Enter quantity: ");
                        quantity = Integer.parseInt(cin.nextLine());
                        System.out.print("Enter price: ");
                        price = Double.parseDouble(cin.nextLine());
                        
                        i = new Items(name, quantity, price);

                        if(eoc.addItem(i)){
                            System.out.println("Item successfully added.");
                        }
                        else{
                            System.out.println("Item not added.");
                        }
                    }
                    
                    break;      
                case 4:
                    System.out.println("Enter id that you want to edit: ");
                            id = Integer.parseInt(cin.nextLine());
                            
                            i = eoc.viewSpecificItem(itemId);
                            
                            if(i != null){
                                System.out.print("Enter name: ");
                                name = cin.nextLine();
                                System.out.print("Enter quantity: ");
                                quantity = Integer.parseInt(cin.nextLine());
                                System.out.print("Enter price: ");
                                price = Double.parseDouble(cin.nextLine());
                                i = new Items(name, quantity, price);

                                    if(eoc.editEntry(i)){
                                        System.out.println("Item successfully edited.");
                                    }
                                    else{
                                        System.out.println("Editing failed.");
                                    }  
                            }    
                    break;
                case 5:
                    System.out.println("Enter id that you want to delete: ");
                    id = Integer.parseInt(cin.nextLine());;
                        
                    if(eoc.deleteItem(id)){
                        System.out.println("Item successfully deleted.");
                    }
                    else{
                        System.out.println("Deleting failed.");
                    }
                    break;
            }
        }
        while(choice != 6);
    }   
}
