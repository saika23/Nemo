/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author chris
 */
import java.sql.*;
import Model.Items;
import java.util.*;

public class ItemsObjectController {
    private Connection conn;
    private PreparedStatement pstm;    
    public void establishConnection()
    {
        try
        {
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost/itemsdb", "root", "");
        }
        catch(Exception ex)
        {
            System.out.println("Can't establish connection. " + ex);
        }
    }
    
    public boolean addItem(Items e){
        this.establishConnection();
        boolean success = false;
        String query = "INSERT INTO tbl_items(name, quantity, price) VALUES(?, ?, ?)";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, e.getName());
            this.pstm.setInt(2, e.getQuantity());
            this.pstm.setDouble(3, e.getPrice());
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't add item. " + ex);
        }
        
        return success;
    }
    
    public boolean editEntry(Items e) {
        this.establishConnection();
        boolean success = false;
        String query = "UPDATE tbl_items SET name = ?, quantity = ? , price = ? WHERE id = ?";
        
        try{
                this.pstm = this.conn.prepareStatement(query);
                this.pstm.setString(1, e.getName());
                this.pstm.setInt(2, e.getQuantity());
                this.pstm.setDouble(3, e.getPrice());
                this.pstm.setInt(4, e.getId());

                this.pstm.executeUpdate();
                success = true; 
        }  
        catch(Exception ex){
            System.out.println("Can't edit items. " + ex);
        }
        
        return success;
    }
    
    public boolean deleteItem(int id){
        this.establishConnection();
        boolean success = false;
        String query = "DELETE FROM tbl_items WHERE id = ?";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, id);
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't delete item. " + ex);
        }
        
        return success;
    }
    
    public ArrayList<Items> showAllItems(){
        this.establishConnection();
        String query = "SELECT * FROM tbl_items";
        Items i = null;
        ArrayList<Items> itemList = new ArrayList<>();
        ResultSet rs = null;
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            rs = this.pstm.executeQuery();
            while(rs.next()){
                int id = rs.getInt(1);
                String name = rs.getString(2);
                int quantity = rs.getInt(3);
                double price = rs.getDouble(4);
                
                i = new Items(id, name, quantity, price);
                itemList.add(i);
            }
        }
        catch(Exception ex){
            System.out.println("Can't view the list of items. " + ex);
        }
        
        return itemList;
    }
    
      public Items viewSpecificItem(int itemId){
        
        this.establishConnection();
        Items i = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM tbl_items WHERE id = ?";
        
        try{
        
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, itemId);
            
            rs = this.pstm.executeQuery();
            
            if(rs.next()){
                int id = rs.getInt(1);
                String name = rs.getString(2);
                int quantity = rs.getInt(3);
                double price = rs.getDouble(4);

                i = new Items(id, name, quantity, price);
            }
            
            else{
                throw new Exception("This item ID does not exist");
            }
            
        } catch(Exception ex){
            System.out.println("Cannot select item. " + ex);
        }
        
        return i;
    }
    
    public boolean duplicateItem(String name){
        this.establishConnection();
        boolean duplicate = false;
        ResultSet rs = null;

        String query = "SELECT name FROM tbl_items WHERE name = ?";

        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, name);

            rs = this.pstm.executeQuery();

            if (rs.next() == false) {
                duplicate = false;
            } else {
                duplicate = true;
                System.out.println("Item name already exists.\n");
            }
        } catch(Exception ex){
            System.out.println("Cannot add item. " + ex);
        }
        return duplicate;
    }
}
