/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mathmethods;

/**
 *
 * @author chris
 */

import java.util.*;

public class MathMethods {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        int opt;
        
        do {
            System.out.println("1.Perimeter of rectangle");
            System.out.println("2.Factorial of a number");
            System.out.println("3.Area of triangle");
            System.out.println("4.Exit");
            System.out.println("Enter option:");
            opt = Integer.parseInt(sc.nextLine());
            
            switch(opt)
            {
                case 1:
                    perimeter();
                    break;
                case 2:
                    int result;
                    result = factorial();
                    System.out.println("The factorial of number is " + result);
                    break;
                case 3:
                    double num1, num2;
                    System.out.println("Enter first number: ");
                    num1 = Double.parseDouble(sc.nextLine());
                    System.out.println("Enter second number: ");
                    num2 = Double.parseDouble(sc.nextLine());
                    
                    area(num1, num2);
                    break;
                case 4:
                    System.out.print("Exiting");
                    break;
            }
        } while (opt != 4);
        
    }
    
    public static void perimeter() {
        Scanner sc = new Scanner(System.in);
        double num1, num2, perm;
        
        System.out.print("Enter length: ");
        num1 = Double.parseDouble(sc.nextLine());
        System.out.print("Enter width: ");
        num2 = Double.parseDouble(sc.nextLine());
        
        perm = 2*num1 + 2*num2;
        
        System.out.println("The perimeter is " + perm);
    }
    
    public static int factorial(){
        Scanner sc = new Scanner(System.in);
        int result;
        result = 1;
        int num1;
        
        System.out.println("Input number: ");
        num1 = Integer.parseInt(sc.nextLine());
        int i;
        
            for (i = 1; i <= num1; i++) {
            result *= i;
        }
           
        return result;
    }
    
    public static void area(double num1, double num2)
    {
        double prod;
        prod = .5*num1*num2;
        
        System.out.println("The area is " + prod);
    }
}
