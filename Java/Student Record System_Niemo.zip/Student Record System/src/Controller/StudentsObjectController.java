/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author chris
 */
import Model.*;
import java.util.*;
import java.sql.*;

public class StudentsObjectController {
    private Connection conn;
    private PreparedStatement pstm;
    
    public void establishConnection(){
        try{
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost/studentrecorddb", "root", "");
        }
        catch(Exception e){
            System.out.println("Can't establish connection. " + e);
        }
    }
    
    public boolean addStudent(Students s2, int teacherId){
        boolean success = false;
    
        this.establishConnection();
        String query = "INSERT INTO tbl_students (student_id, name, grade, teacher_id) VALUES(?,?,?,?)";
        
        try{
        this.pstm = this.conn.prepareStatement(query);
        this.pstm.setString(1, s2.getStudent_id());
        this.pstm.setString(2, s2.getName());
        this.pstm.setDouble(3, s2.getGrade());
        this.pstm.setInt(4, teacherId);
        
        this.pstm.executeUpdate();
        success = true;
        }
        catch (Exception ex) {
            System.out.println(ex);
            
        }
        
        return success;
    }
    
     public boolean updateStudent (Students s3, String studentId)
     {
        boolean success = false;
    
        this.establishConnection();
        String query = "UPDATE tbl_students SET student_id = ?, name = ?, grade = ? WHERE student_id = ?";
        
        try{
            this.pstm = this.conn.prepareStatement(query);


            this.pstm.setString(1, s3.getStudent_id());
            this.pstm.setString(2, s3.getName());
            this.pstm.setDouble(3, s3.getGrade());
            this.pstm.setString(4, studentId);
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch (Exception ex) {
            System.out.println("Student not updated." + ex);
            
        }
        
        return success;
    }
     
    public boolean deleteStudent (String studentId){
        boolean success = false;
    
        this.establishConnection();
        String query = "DELETE FROM tbl_students WHERE student_id = ?";
        
        try{
        this.pstm = this.conn.prepareStatement(query);
        this.pstm.setString(1, studentId);
        
        this.pstm.executeUpdate();
        success = true;
        }
        catch (Exception ex) {
            System.out.println("Student not deleted." + ex); 
        }
        return success;
    }
    
    public ArrayList<Students> viewAll(int teacherId){
     
         ArrayList<Students> studentsList = new ArrayList<>();
         
         this.establishConnection();
         Students s2 = null;
         ResultSet rs = null;
         String query = "SELECT * FROM tbl_students WHERE teacher_id = ?";
         
         try{
             this.pstm = this.conn.prepareStatement(query);
             this.pstm.setInt(1, teacherId);
             rs = this.pstm.executeQuery();
             
             while(rs.next()){
                 String student_id = rs.getString("student_id");
                 String name = rs.getString("name");
                 double grade = rs.getDouble("grade");

                 s2 = new Students(student_id, name, grade);
                 studentsList.add(s2);
             }
             
            
         }catch(Exception ex){
                System.out.println("Cannot view students." + ex);
         }
         
         return studentsList;
     }
    
     public Students viewSpecificStudent(String studentId){
        
        this.establishConnection();
        Students i = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM tbl_students WHERE student_id = ?";
        
        try{
        
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, studentId);
            
            rs = this.pstm.executeQuery();
            
           rs.next();
                studentId = rs.getString("student_id");
                String name = rs.getString("name");
                double grade = rs.getDouble("grade");

                i = new Students(studentId, name, grade);

            
        } catch(Exception ex){
            System.out.println("Cannot select item. " + ex);
        }
        
        return i;
    }
     
     public boolean idCheck(String studentId) {
        this.establishConnection();
        boolean exist = false;
        ResultSet rs = null;
        
        String query = "SELECT student_id FROM tbl_students WHERE student_id = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, studentId);
            
            rs = this.pstm.executeQuery();
            
            if(rs.next() == false) {
                exist = false;
            } else {
                exist = true;
            }
        }
        catch(Exception ex) {
            System.out.println("Error: " + ex);
        }
        
        return exist;
    }
}
