/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
/**
 *
 * @author chris
 */
import Model.Teachers;
import java.sql.*;

public class TeachersObjectController {
    private Connection conn;
    private PreparedStatement pstm;
    
    public void establishConnection(){
        try{
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost/studentrecorddb", "root", "");
        }
        catch(Exception e){
            System.out.println("Can't establish connection. " + e);
        }
    }
    
    public boolean Register(Teachers t){
        this.establishConnection();
        boolean success = false;
        
        String query = "INSERT INTO tbl_teachers (name, username, password) VALUES (?, ?, ?)";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, t.getName());
            this.pstm.setString(2, t.getUsername());
            this.pstm.setString(3, t.getPassword());
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch (Exception ex) {
            System.out.println(ex); 
        }
        
        return success;
    }
    
    public boolean nameChecker(String registerUsername) {
        this.establishConnection();
        boolean exist = false;
        ResultSet rs = null;
        
        String query = "SELECT username FROM tbl_teachers WHERE username = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, registerUsername);
            
            rs = this.pstm.executeQuery();
            
            if(rs.next() == false) {
                exist = false;
            } else {
                exist = true;
            }
        }
        catch(Exception ex) {
            System.out.println("Error: " + ex);
        }
        
        return exist;
    }
    
    public Teachers getAccountData(String username){
        this.establishConnection();
        Teachers t = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM tbl_teachers WHERE username = ?";
        
        try{
            
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, username);
            rs = this.pstm.executeQuery();
            rs.next();
            
            t = new Teachers(
                rs.getInt("id"), 
                rs.getString("name"), 
                rs.getString("username"), 
                rs.getString("password")
            );
            
        } catch(SQLException ex){
            System.out.println("SQL Error: " + ex);
        } catch(Exception ex){
            System.out.println("Strange Error: " + ex);
        }
        
        return t;
    }
    
     public boolean verifyLogin(Teachers t){
        
        this.establishConnection();
        boolean success = false;
        ResultSet rs = null;
        
        String query = "SELECT COUNT(*) as countValidLogin FROM tbl_teachers WHERE username = ? AND password = ?";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, t.getUsername());
            this.pstm.setString(2, t.getPassword());
            
            rs = this.pstm.executeQuery();
            rs.next();
            if(rs.getInt("countValidLogin") == 1){
                success = true;
            }
            
        } catch(SQLException ex){
            System.out.println("SQL Error: " + ex);
        } catch(Exception ex){
            System.out.println("Strange Error: " + ex);
        }
        
        return success;
    }
}
    
  
