/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author chris
 */
public class Students {
    private int id;
    private String student_id;
    private String name;
    private double grade;
    private int teacher_id;

    public Students(int id, String student_id, String name, double grade, int teacher_id) {
        this.id = id;
        this.student_id = student_id;
        this.name = name;
        this.grade = grade;
        this.teacher_id = teacher_id;
    }

    public Students(String student_id, String name, double grade, int teacher_id) {
        this.student_id = student_id;
        this.name = name;
        this.grade = grade;
        this.teacher_id = teacher_id;
    }
    
    public Students(String student_id, String name, double grade) {
        this.student_id = student_id;
        this.name = name;
        this.grade = grade;
        this.teacher_id = teacher_id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setStudent_id(String student_id) {
        this.student_id = student_id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public void setTeacher_id(int teacher_id) {
        this.teacher_id = teacher_id;
    }

    public int getId() {
        return id;
    }

    public String getStudent_id() {
        return student_id;
    }

    public String getName() {
        return name;
    }

    public double getGrade() {
        return grade;
    }

    public int getTeacher_id() {
        return teacher_id;
    }
    
    
}
