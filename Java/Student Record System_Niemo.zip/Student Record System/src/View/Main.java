/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

/**
 *
 * @author chris
 */
import java.util.*;
import Model.*;
import Controller.*;

public class Main 
{
    public static void main(String []args){
        Scanner cin = new Scanner (System.in);
        
        StudentsObjectController soc = new StudentsObjectController();
        TeachersObjectController toc = new TeachersObjectController();
        
        String choice = "";
        do 
        {
            System.out.println("[1] Login");
            System.out.println("[2] Register");
            System.out.println("[3] Exit");
            System.out.println("Pick your Choice: ");
            choice = cin.nextLine();
            
            switch(choice)
            {
                case "1":
                    String username = "", password = "";
                    System.out.println("Enter username: ");
                    username = cin.nextLine();
                    System.out.println("Enter Password: ");
                    password = cin.nextLine();
                    
                    Teachers t = new Teachers(username, password);
                    
                    if(toc.verifyLogin(t)) {
                        t = toc.getAccountData(t.getUsername());
                        do {
                            choice = "";
                            System.out.println("[1]View students");
                            System.out.println("[2]Search a student");
                            System.out.println("[3]Add a student");
                            System.out.println("[4]Edit a student");
                            System.out.println("[5]Remove a student");
                            System.out.println("[6]Logout");
                            System.out.print("Choose an option: ");
                            choice = cin.nextLine();
                                         
                            switch(choice){
                                case "1":
                                    ArrayList<Students> studentsList = soc.viewAll(t.getId());

                                    if(!studentsList.isEmpty()) {
                                        for(Students s2: studentsList) {
                                            System.out.println("Student ID: " + s2.getStudent_id());
                                            System.out.println("Student Name: " + s2.getName());
                                            System.out.println("Student Grade: " + s2.getGrade());
                                        }
                                    } else {
                                        System.out.println("No Student Record.");
                                    }
                                break;

                                case "2":
                                    String studentId = "";
                                    System.out.print("Enter Student ID: ");
                                    studentId = cin.nextLine();

                                    Students s = soc.viewSpecificStudent(studentId);

                                    if(s != null) {
                                        System.out.println("Student ID: " + s.getStudent_id());
                                        System.out.println("Student Name: " + s.getName());
                                        System.out.println("Student Grade: " + s.getGrade());
                                    }
                                break;

                                case "3":
                                    String name = "";
                                    System.out.println("Debug" + t.getId());
                                    double grade = 0;

                                    System.out.print("Enter student ID: ");
                                    studentId = cin.nextLine();

                                    if(soc.idCheck(studentId) == false) {
                                        System.out.print("Enter student name: ");
                                        name = cin.nextLine();
                                        System.out.print("Enter grade: ");
                                        grade = Double.parseDouble(cin.nextLine());

                                        s = new Students(studentId, name, grade);

                                        if(soc.addStudent(s, t.getId()) == true) {
                                            System.out.println("Student successfully added.\n");
                                        }
                                    } else {
                                        System.out.println("ID Already Exist.\n");
                                    }
                                break;

                                case "4":
                                    String dstudentId = "";
                                    System.out.print("Enter student ID: ");
                                    dstudentId = cin.nextLine();

                                    s = soc.viewSpecificStudent(dstudentId);

                                    if(s != null) {
                                        System.out.println("Student ID: " + s.getStudent_id());
                                        System.out.println("Student name: " + s.getName());
                                        System.out.println("Grade: " + s.getGrade());

                                        System.out.print("Enter new student ID: ");
                                        studentId = cin.nextLine();

                                        if(soc.idCheck(studentId) == false) {
                                            System.out.print("Enter new student name: ");
                                            name = cin.nextLine();
                                            System.out.print("Enter new grade: ");
                                            grade = Double.parseDouble(cin.nextLine());

                                            s = new Students(studentId, name, grade);

                                            if(soc.updateStudent(s, dstudentId) == true) {
                                                System.out.println("Student successfully updated.\n");
                                            }
                                        } else {
                                            System.out.println("ID Already Exist.\n");
                                        }
                                    }
                                break;

                                case "5":
                                    String astudentId = "";
                                    System.out.print("Enter student ID you want to delete: ");
                                    astudentId = cin.nextLine();
                                    
                                    if(soc.deleteStudent(astudentId)) 
                                    {
                                        System.out.println("Student successfully removed.");
                                    }
                                break;

                                case "6":
                                break;
                                
                                default:

                            }
                        } while(!choice.equals("6"));
                    } else {
                        System.out.println("Invalid Credentials.");
                    }
                    
                break;
                case "2":
                    String registerName = "", registerUsername = "", registerPassword = "";
                    
                    System.out.print("Enter your name: ");
                    registerName = cin.nextLine();
                    
                    if(toc.nameChecker(registerUsername) == false) {
                        System.out.print("Enter username: ");
                        registerUsername = cin.nextLine();
                        System.out.print("Enter password: ");
                        registerPassword = cin.nextLine();

                        t = new Teachers(registerName, registerUsername, registerPassword);

                        if(toc.Register(t) == true) {
                            System.out.println("Account successfully added.");
                        }  
                    } else {
                        System.out.println("Username Already Exist.");
                    }
                break;
                case "3":
                    break;
                default: System.out.println("Invalid Choice");
                break;
            }
        } while (!choice.equals("3")); 
    }
    
    
}
