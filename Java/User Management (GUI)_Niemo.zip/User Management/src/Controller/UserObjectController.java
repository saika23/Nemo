/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author chris
 */

import java.sql.*;
import Model.User;
import java.util.*;

public class UserObjectController 
{
    private Connection conn;
    private PreparedStatement pstm;
    
    public void establishConnection()
    {
        try
        {
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost/usersdb", "root", "");
        }
        catch(Exception ex)
        {
            System.out.println("Can't establish connection. " + ex);
        }
    }
    
    public boolean addUser(User a){
        this.establishConnection();
        boolean success = false;
        String query = "INSERT INTO tbl_users(name, age, address) VALUES(?, ?, ?)";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, a.getName());
            this.pstm.setInt(2, a.getAge());
            this.pstm.setString(3, a.getAddress());
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't add user. " + ex);
        }
        
        return success;
    }
    
    public boolean editUser(User a) {
        this.establishConnection();
        boolean success = false;
        String query = "UPDATE tbl_users SET name = ?, age = ?, address = ? WHERE id = ?";
        
        try{
                this.pstm = this.conn.prepareStatement(query);
                this.pstm.setString(1, a.getName());
                this.pstm.setInt(2, a.getAge());
                this.pstm.setString(3, a.getAddress());
                this.pstm.setInt(4, a.getId());

                this.pstm.executeUpdate();
                success = true; 
        }  
        catch(Exception ex){
            System.out.println("Can't update user. " + ex);
        }
        
        return success;
    }
    
    public boolean deleteUser(int id){
        this.establishConnection();
        boolean success = false;
        String query = "DELETE FROM tbl_users WHERE id = ?";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, id);
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't delete user. " + ex);
        }
        
        return success;
    }
    
    public ArrayList<User> showAllUsers(){
        this.establishConnection();
        String query = "SELECT * FROM tbl_users ORDER BY id ASC";
        User u = null;
        ArrayList<User> userList = new ArrayList<>();
        ResultSet rs = null;
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            rs = this.pstm.executeQuery();
            while(rs.next()){
                int id = rs.getInt(1);
                String name = rs.getString(2);
                int age = rs.getInt("age");
                String address = rs.getString("address");
                
                u = new User(id, name, age, address);
                userList.add(u);
            }
        }
        catch(Exception ex){
            System.out.println("Can't view the list of users. " + ex);
        }
        
        return userList;
    }
    
      public User viewSpecificUser(int userID){
        
        this.establishConnection();
        User u = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM tbl_users WHERE id = ?";
        
        try{
        
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, userID);
            
            rs = this.pstm.executeQuery();
            
            if(rs.next()){
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String address =  rs.getString("address");

                u = new User(id, name, age, address);
            }
            
            else{
                throw new Exception("This user ID does not exist");
            }
            
        } catch(Exception ex){
            System.out.println("Cannot select user. " + ex);
        }
        
        return u;
    }
   
}
