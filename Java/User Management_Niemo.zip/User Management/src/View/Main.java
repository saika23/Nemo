/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

/**
 *
 * @author chris
 */

import Controller.UserObjectController;
import Model.User;
import java.util.*;

public class Main 
{
     public static void main(String args[]) throws Exception
     {
        Scanner cin = new Scanner(System.in);
         
        int choice = 0, id = 0, age = 0, userId = 0;
        String name = "", address = "";
        
        UserObjectController uoc = new UserObjectController();
        User a = null;
        do
        {
            System.out.println("[1] Add user");
            System.out.println("[2] Show users");
            System.out.println("[3] Edit user");
            System.out.println("[4] Delete user");
            System.out.println("[5] View Specific User");
            System.out.println("[6] Exit");
            System.out.print("Choose an option: ");
            choice = Integer.parseInt(cin.nextLine());
            
            switch(choice)
            {
                case 1: 
                    System.out.print("Enter name: ");
                    name = cin.nextLine();
                    System.out.print("Enter age: ");
                    age = Integer.parseInt(cin.nextLine());
                    System.out.print("Enter address: ");
                    address = cin.nextLine();
                    a = new User(name, age, address);
                        
                    if(uoc.addUser(a)){
                        System.out.println("User successfully added.");
                    }
                    else{
                        System.out.println("User not added.");
                    }
                    break;
                case 2:
                    ArrayList<User> userList = uoc.showAllUsers();
                        if(userList != null){
                            for(User u2 : userList){
                                System.out.println("ID: " + u2.getId());
                                System.out.println("Name: " + u2.getName());
                                System.out.println("Age: " + u2.getAge());
                                System.out.println("Address: " + u2.getAddress());
                            }
                        }
                        else{
                            System.out.println("No users found.");
                        }
                        break;
                case 3:
                          
                    System.out.println("Enter id that you want to edit: ");
                            id = Integer.parseInt(cin.nextLine());
                            
                            a = uoc.viewSpecificUser(userId);
                            
                            if(a != null){
                            System.out.print("Enter name: ");
                            name = cin.nextLine();
                            System.out.print("Enter age: ");
                            age = Integer.parseInt(cin.nextLine());
                            System.out.print("Enter address: ");
                            address = cin.nextLine();
                            a = new User(id, name, age, address);

                                if(uoc.editUser(a)){
                                    System.out.println("User successfully edited.");
                                }
                                else{
                                    System.out.println("Editing failed.");
                                }  
                            }    
                    break;
                case 4:
                    System.out.println("Enter id that you want to delete: ");
                    id = Integer.parseInt(cin.nextLine());;
                        
                    if(uoc.deleteUser(id)){
                        System.out.println("User successfully deleted.");
                    }
                    else{
                        System.out.println("Deleting failed.");
                    }
                    break;
                case 5:
                    System.out.print("Enter user id: ");
                    userId = Integer.parseInt(cin.nextLine());
                    
                    a = uoc.viewSpecificUser(userId);
                    
                    if (a != null) {
                        System.out.println("User ID: " + a.getId());
                        System.out.println("Name: " + a.getName());
                        System.out.println("Age: " + a.getAge());
                        System.out.println("Address: " + a.getAddress());
                    }
                    
                    break;
            }
        }
        while(choice != 6);
    }   
}
